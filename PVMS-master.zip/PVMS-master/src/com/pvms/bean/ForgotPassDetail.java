package com.pvms.bean;

public class ForgotPassDetail {
	private
String hques;
String hans;
String pass;


public ForgotPassDetail() {
	super();
}
public String getHques() {
	return hques;
}
public void setHques(String hques) {
	this.hques = hques;
}
public String getHans() {
	return hans;
}
public void setHans(String hans) {
	this.hans = hans;
}
public String getPass() {
	return pass;
}
public void setPass(String pass) {
	this.pass = pass;
}



}
