Passport and Visa Management System. MFRP for Cognizant Academy.
Demonstrates understanding of Core Java and basic Java EE concepts like JSP and Servlets.

P.S : - The database used here is Oracle 11g . To use MySQL or anything else the queries would need to be converted.
